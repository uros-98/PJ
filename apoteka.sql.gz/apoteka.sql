-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2024 at 12:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apoteka`
--

-- --------------------------------------------------------

--
-- Table structure for table `leknarudzbina`
--

CREATE TABLE `leknarudzbina` (
  `id` int(11) NOT NULL,
  `Id_leka` int(15) NOT NULL,
  `Id_narudzbine` int(11) NOT NULL,
  `kolicina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leknarudzbina`
--

INSERT INTO `leknarudzbina` (`id`, `Id_leka`, `Id_narudzbine`, `kolicina`) VALUES
(1, 1, 1, 5),
(2, 2, 1, 10),
(3, 3, 1, 3),
(4, 1, 2, 20),
(5, 3, 2, 18),
(6, 4, 2, 27),
(7, 1, 3, 50),
(8, 2, 3, 60),
(9, 3, 3, 70),
(22, 1, 4, 200),
(23, 2, 4, 250),
(24, 3, 4, 350);

-- --------------------------------------------------------

--
-- Table structure for table `lekovi`
--

CREATE TABLE `lekovi` (
  `id` int(15) NOT NULL,
  `naziv` varchar(50) NOT NULL,
  `tip` varchar(50) NOT NULL,
  `proizvodjac` varchar(255) NOT NULL,
  `rok_trajanja` datetime(6) DEFAULT NULL,
  `cena` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lekovi`
--

INSERT INTO `lekovi` (`id`, `naziv`, `tip`, `proizvodjac`, `rok_trajanja`, `cena`) VALUES
(1, 'Lek1', 'Tip1', 'Pera', '2024-01-31 00:00:00.000000', 0),
(2, 'Lek2', 'Tip1', 'Mika', '2024-01-31 00:00:00.000000', 0),
(3, 'Lek3', 'Tip1', 'Mika', '2024-01-31 00:00:00.000000', 0),
(4, 'Lek4', 'Tip2', 'Pera', '2024-01-31 00:00:00.000000', 0),
(5, 'Lek22', 'Tip1', 'Proiz1', '2012-04-03 02:00:00.000000', 25);

-- --------------------------------------------------------

--
-- Table structure for table `lekprodaja`
--

CREATE TABLE `lekprodaja` (
  `id` int(11) NOT NULL,
  `id_leka` int(11) NOT NULL,
  `id_prodaje` int(11) NOT NULL,
  `kolicina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lekprodaja`
--

INSERT INTO `lekprodaja` (`id`, `id_leka`, `id_prodaje`, `kolicina`) VALUES
(4, 1, 1, 2),
(5, 2, 1, 5),
(6, 3, 1, 15);

-- --------------------------------------------------------

--
-- Table structure for table `narudzbenica`
--

CREATE TABLE `narudzbenica` (
  `id` int(11) NOT NULL,
  `datum` datetime DEFAULT NULL,
  `status_isporuke` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `narudzbenica`
--

INSERT INTO `narudzbenica` (`id`, `datum`, `status_isporuke`) VALUES
(1, '2024-01-07 17:11:12', 'Naruceno'),
(2, '2024-01-08 17:11:12', 'Isporuceno'),
(3, '2012-04-03 02:00:00', 'Kreirano'),
(4, '2018-01-20 01:00:00', 'Azurirano');

-- --------------------------------------------------------

--
-- Table structure for table `prodaja`
--

CREATE TABLE `prodaja` (
  `id` int(3) NOT NULL,
  `datum` datetime DEFAULT NULL,
  `ukupna_cena` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prodaja`
--

INSERT INTO `prodaja` (`id`, `datum`, `ukupna_cena`) VALUES
(1, '2024-01-01 18:26:00', 25000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leknarudzbina`
--
ALTER TABLE `leknarudzbina`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_narudzbina` (`Id_narudzbine`),
  ADD KEY `fk_lek1` (`Id_leka`);

--
-- Indexes for table `lekovi`
--
ALTER TABLE `lekovi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lekprodaja`
--
ALTER TABLE `lekprodaja`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lek2` (`id_leka`),
  ADD KEY `fk_prodaje` (`id_prodaje`);

--
-- Indexes for table `narudzbenica`
--
ALTER TABLE `narudzbenica`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prodaja`
--
ALTER TABLE `prodaja`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leknarudzbina`
--
ALTER TABLE `leknarudzbina`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `lekovi`
--
ALTER TABLE `lekovi`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lekprodaja`
--
ALTER TABLE `lekprodaja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `narudzbenica`
--
ALTER TABLE `narudzbenica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prodaja`
--
ALTER TABLE `prodaja`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leknarudzbina`
--
ALTER TABLE `leknarudzbina`
  ADD CONSTRAINT `fk_lek1` FOREIGN KEY (`Id_leka`) REFERENCES `lekovi` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_narudzbina` FOREIGN KEY (`Id_narudzbine`) REFERENCES `narudzbenica` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `lekprodaja`
--
ALTER TABLE `lekprodaja`
  ADD CONSTRAINT `fk_lek2` FOREIGN KEY (`id_leka`) REFERENCES `lekovi` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prodaje` FOREIGN KEY (`id_prodaje`) REFERENCES `prodaja` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `narudzbenica`
--
ALTER TABLE `narudzbenica`
  ADD CONSTRAINT `fk_lek` FOREIGN KEY (`id`) REFERENCES `lekovi` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
