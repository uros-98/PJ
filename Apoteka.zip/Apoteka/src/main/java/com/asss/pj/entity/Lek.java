package com.asss.pj.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "lekovi")
public class Lek {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String naziv, tip, proizvodjac;
    private double cena;
    private Date rokTrajanja;

    public Lek() {

    }

    public Lek(int id, String naziv, String tip, String proizvodjac, double cena, Date rokTrajanja) {
        this.id = id;
        this.naziv = naziv;
        this.tip = tip;
        this.proizvodjac = proizvodjac;
        this.cena = cena;
        this.rokTrajanja = rokTrajanja;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getProizvodjac() {
        return proizvodjac;
    }

    public void setProizvodjac(String proizvodjac) {
        this.proizvodjac = proizvodjac;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public Date getRokTrajanja() {
        return rokTrajanja;
    }

    public void setRokTrajanja(Date rokTrajanja) {
        this.rokTrajanja = rokTrajanja;
    }
}
