package com.asss.pj.controller;

import com.asss.pj.ViewModels.ProdajaViewModel;
import com.asss.pj.service.ProdajaService;
import com.asss.pj.utility.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/prodaja")
public class ProdajaRestController {

    @Autowired
    private ProdajaService prodajaService;

    @GetMapping("/{id}")
    public ProdajaViewModel dajProdajuPoId(@PathVariable int id) {
        Logger.upisivanjeRequestULogger("Get", "/prodaja/" + id, "");
        ProdajaViewModel response = prodajaService.dajProdajuPoId(id);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @GetMapping("/dajSveProdaje")
    public List<ProdajaViewModel> dajSveProdaje() {
        Logger.upisivanjeRequestULogger("Get", "/prodaja/dajSveProdaje", "");
        List<ProdajaViewModel> response = prodajaService.dajSveProdaje();
        Logger.upisivanjeResponseULogger(response);
        return response;
    }
}
