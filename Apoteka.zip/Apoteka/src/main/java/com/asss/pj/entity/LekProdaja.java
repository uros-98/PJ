package com.asss.pj.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "lekprodaja")
public class LekProdaja {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int idLeka, idProdaje;
    private int kolicina;

    public LekProdaja(int id, int idLeka, int idProdaje, int kolicina) {
        this.id = id;
        this.idLeka = idLeka;
        this.idProdaje = idProdaje;
        this.kolicina = kolicina;
    }

    public LekProdaja() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdLeka() {
        return idLeka;
    }

    public void setIdLeka(int idLeka) {
        this.idLeka = idLeka;
    }

    public int getIdProdaje() {
        return idProdaje;
    }

    public void setIdProdaje(int idProdaje) {
        this.idProdaje = idProdaje;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }
}
