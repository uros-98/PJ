package com.asss.pj.service;

import com.asss.pj.ViewModels.LekKolicinaViewModel;
import com.asss.pj.ViewModels.ProdajaViewModel;
import com.asss.pj.dao.LekProdajaRepository;
import com.asss.pj.dao.LekRepository;
import com.asss.pj.dao.ProdajaRepository;
import com.asss.pj.entity.Lek;
import com.asss.pj.entity.LekProdaja;
import com.asss.pj.entity.Prodaja;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProdajaServiceImpl implements ProdajaService{

    @Autowired
    ProdajaRepository prodajaRepository;
    @Autowired
    LekProdajaRepository lekProdajaRepository;
    @Autowired
    LekRepository lekRepository;
    @Override
    public ProdajaViewModel dajProdajuPoId(int id) {
        Prodaja p = prodajaRepository.findById(id);
        List<LekProdaja> lekProdajas = lekProdajaRepository.getLekByProdajaId(p.getId());
        List<LekKolicinaViewModel> lekovi = new ArrayList<LekKolicinaViewModel>();
        for (LekProdaja lekProdaja: lekProdajas) {
            Lek lek = lekRepository.findById(lekProdaja.getIdLeka());
            LekKolicinaViewModel lekKolicinaViewModel = new LekKolicinaViewModel();
            lekKolicinaViewModel.setLek(lek);
            lekKolicinaViewModel.setKolicina(lekProdaja.getKolicina());
            lekovi.add(lekKolicinaViewModel);
        }

        ProdajaViewModel prodajaViewModel = new ProdajaViewModel();
        prodajaViewModel.setUkupnaCena(p.getUkupnaCena());
        prodajaViewModel.setDatum(p.getDatum());
        prodajaViewModel.setLekovi(lekovi);

        return prodajaViewModel;
    }

    public List<ProdajaViewModel> dajSveProdaje() {
        List<Prodaja> prodaje = prodajaRepository.findAll();
        List<ProdajaViewModel> result = new ArrayList<ProdajaViewModel>();

        for (Prodaja prodaja: prodaje) {
            ProdajaViewModel prodajaViewModel =  dajProdajuPoId(prodaja.getId());
            result.add(prodajaViewModel);
        }

        return result;
    }

    @Override
    public List<LekProdaja> getLekProdaja(int id) {
        return lekProdajaRepository.getLekByProdajaId(id);
    }
}
