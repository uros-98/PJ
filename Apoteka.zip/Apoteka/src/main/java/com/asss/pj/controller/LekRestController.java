package com.asss.pj.controller;

import com.asss.pj.ViewModels.LekViewModel;
import com.asss.pj.entity.Lek;
import com.asss.pj.service.LekService;
import com.asss.pj.utility.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/lek")
public class LekRestController {
    @Autowired
    private LekService lekService;

    @GetMapping("/dajSve")
    public List<Lek> findAll() {
        Logger.upisivanjeRequestULogger("Get", "/lek/dajSve", "");
        List<Lek> response = lekService.findAll();
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @GetMapping("/{id}")
    public Lek pretraziLekPoId(@PathVariable int id) {
        Logger.upisivanjeRequestULogger("Get", "/lek/" + id, "");
        Lek lek = lekService.pretraziLekPoId(id);
        Logger.upisivanjeResponseULogger(lek);
        return lek;
    }

    @GetMapping("/dajPoNazivu/{naziv}")
    public List<Lek> pretraziLekPoNazivu(@PathVariable String naziv) {
        List<Lek> response = lekService.pretraziLekPoNazivu(naziv);
         return response;
    }

    @PostMapping("/dodaj")
    public Object dodajLek(@RequestBody LekViewModel lek) {
        Logger.upisivanjeRequestULogger("Post", "/lek/dodaj", lek);
        Object response = lekService.dodajLek(lek);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @PostMapping("/izmeni/{id}")
    public String izmeniLek(@PathVariable int id, @RequestBody LekViewModel lek) {
        Logger.upisivanjeRequestULogger("Post", "/lek/izmeni/" + id, lek);
        String response = lekService.izmeniLek(id, lek);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @DeleteMapping("/obrisi/{id}")
    public String obrisiLek(@PathVariable int id) {
        Logger.upisivanjeRequestULogger("Delete", "/lek/obrisi/" + id, "");
        String response = lekService.obrisiLek(id);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }
}
