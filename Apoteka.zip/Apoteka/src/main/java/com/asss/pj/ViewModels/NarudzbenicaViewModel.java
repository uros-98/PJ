package com.asss.pj.ViewModels;

import java.util.Date;
import java.util.List;

public class NarudzbenicaViewModel {

    private Date datum;
    private String statusIsporuke;
    private List<LekKolicinaViewModel> lekovi;
    public NarudzbenicaViewModel() {
    }

    public NarudzbenicaViewModel(Date datum, String statusIsporuke, List<LekKolicinaViewModel> lekovi) {
        this.datum = datum;
        this.statusIsporuke = statusIsporuke;
        this.lekovi = lekovi;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getStatusIsporuke() {
        return statusIsporuke;
    }

    public void setStatusIsporuke(String statusIsporuke) {
        this.statusIsporuke = statusIsporuke;
    }

    public List<LekKolicinaViewModel> getLekovi() {
        return lekovi;
    }

    public void setLekovi(List<LekKolicinaViewModel> lekovi) {
        this.lekovi = lekovi;
    }
}
