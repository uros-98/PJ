package com.asss.pj.dao;

import com.asss.pj.entity.Prodaja;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ProdajaRepository extends JpaRepository<Prodaja, Integer> {

    @Query("select p from Prodaja p where p.id = ?1")
    Prodaja findById(int id);
}
