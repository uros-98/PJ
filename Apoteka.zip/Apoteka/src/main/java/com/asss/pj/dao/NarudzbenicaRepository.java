package com.asss.pj.dao;

import com.asss.pj.entity.Narudzbenica;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Date;

@Repository
public interface NarudzbenicaRepository extends JpaRepository<Narudzbenica, Integer> {

    @Query("select n from Narudzbenica n where n.id = ?1")
    Narudzbenica getById(int id);

    @Modifying
    @Transactional
    @Query("update Narudzbenica nar set nar.statusIsporuke = :status where nar.id = :id")
    int updateStatus(@Param("id") int id, @Param("status") String status);

    @Modifying
    @Transactional
    @Query("insert into Narudzbenica (datum, statusIsporuke) values (:datum, :status)")
    int dodaj(@Param("datum") Date datum,@Param("status") String status);

    @Query("select max(n.id) from Narudzbenica n")
    int dajNajveciIdNarudzbine();

    @Modifying
    @Transactional
    @Query("update Narudzbenica n set n.datum = :datum, n.statusIsporuke = :statusIsporuke where n.id = :id")
    int izmeni(@Param("id") int id, @Param("datum") Date datum, @Param("statusIsporuke") String statusIsporuke);
}
