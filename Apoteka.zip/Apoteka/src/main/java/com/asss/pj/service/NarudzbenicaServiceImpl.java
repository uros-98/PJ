package com.asss.pj.service;

import com.asss.pj.ViewModels.*;
import com.asss.pj.dao.LekNarudzbinaRepository;
import com.asss.pj.dao.LekRepository;
import com.asss.pj.dao.NarudzbenicaRepository;
import com.asss.pj.entity.Lek;
import com.asss.pj.entity.LekNarudzbina;
import com.asss.pj.entity.Narudzbenica;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class NarudzbenicaServiceImpl implements NarudzbenicaService{

    @Autowired
    NarudzbenicaRepository narudzbenicaRepository;
    @Autowired
    LekNarudzbinaRepository lekNarudzbinaRepository;
    @Autowired
    LekRepository lekRepository;

    @Override
    public List<Narudzbenica> findAll() {
        return narudzbenicaRepository.findAll();
    }

    @Override
    public NarudzbenicaViewModel dajNarudzbenicuPoId(int id) {
        Narudzbenica narudzbenica = narudzbenicaRepository.getById(id);
        List<LekNarudzbina> lekNarudzbinas = lekNarudzbinaRepository.dajLekNarudzbinePoNarudzbinaId(narudzbenica.getId());
        List<LekKolicinaViewModel> lekKolicinas = new ArrayList<LekKolicinaViewModel>();
        for (LekNarudzbina lekNarudzbina: lekNarudzbinas) {
            Lek lek = lekRepository.findById(lekNarudzbina.getIdLeka());
            LekKolicinaViewModel lekKolicina = new LekKolicinaViewModel();
            lekKolicina.setKolicina(lekNarudzbina.getKolicina());
            lekKolicina.setLek(lek);
            lekKolicinas.add(lekKolicina);
        }
        NarudzbenicaViewModel narudzbenicaViewModel = new NarudzbenicaViewModel();
        narudzbenicaViewModel.setDatum(narudzbenica.getDatum());
        narudzbenicaViewModel.setStatusIsporuke(narudzbenica.getStatusIsporuke());
        narudzbenicaViewModel.setLekovi(lekKolicinas);

        return narudzbenicaViewModel;
    }
    public String updateStatus(StatusUpdate statusUpdate) {
        int result = narudzbenicaRepository.updateStatus(statusUpdate.getId(), statusUpdate.getStatus());
        if(result == 1) {
            return "Uspesno ste izmenili status narudzbine sa id-em:" + statusUpdate.getId() + " - novi status je: " + statusUpdate.getStatus();
        }
        return  "Niste usposno izmenili status narudzbine sa id-em: " + statusUpdate.getId();
    }
    @Override
    public String kreiranje(NarudzbinaKreiranje novaNarudzbina) {
        int resultDodavanje = narudzbenicaRepository.dodaj(novaNarudzbina.getDatum(), novaNarudzbina.getStatus());
        if (resultDodavanje != 1) {
            return "Niste uspeli da kreirate novu porudzbinu";
        }
        int novaPorudzbinaId = narudzbenicaRepository.dajNajveciIdNarudzbine();
        List<String> uspesno = new ArrayList<String>();
        List<String> neuspesno = new ArrayList<String>();
        for (LekKolicinaBasic lekKolicinaBasic: novaNarudzbina.getLekKolicina()) {
            int resultLekNarudzbina = lekNarudzbinaRepository.dodaj(novaPorudzbinaId, lekKolicinaBasic.getLekId(), lekKolicinaBasic.getKolicina());
            if(resultLekNarudzbina == 1) {
                uspesno.add(lekKolicinaBasic.getLekId() + "");
            }
            else {
                neuspesno.add(lekKolicinaBasic.getLekId() + "");
            }
        }

        String result = "";
        if(uspesno.size() > 0) {
            result += "Uspesno ste dodali lekove sa id-em: ";
            for (String x: uspesno) {
                result += x + ", ";
            }
        }

        if(neuspesno.size() > 0) {
            result += "\nNeuspesno ste dodali lekove sa id-em: ";
            for (String x: neuspesno) {
                result += x + ", ";
            }
        }
        return result;
    }

    public String izmeni(NarudzbinaKreiranje narudzbina) {
        int resultIzmene = narudzbenicaRepository.izmeni(narudzbina.getIdNarudzbenice(), narudzbina.getDatum(), narudzbina.getStatus());
        if (resultIzmene != 1) {
            return "Niste uspesno azurirali datum i status isporuke";
        }
        int resultBrisanje = lekNarudzbinaRepository.obrisiPoNarudzbinaId(narudzbina.getIdNarudzbenice());

        List<String> uspesno = new ArrayList<String>();
        List<String> neuspesno = new ArrayList<String>();
        for (LekKolicinaBasic lekKolicina :narudzbina.getLekKolicina()) {
            int resultDodavanja = lekNarudzbinaRepository.dodaj(narudzbina.getIdNarudzbenice(), lekKolicina.getLekId(), lekKolicina.getKolicina());
            if(resultDodavanja == 1) {
                uspesno.add(lekKolicina.getLekId() + "");
            }
            else {
                neuspesno.add(lekKolicina.getLekId() + "");
            }
        }
        String result = "";
        if(uspesno.size() > 0) {
            result += "Uspesno ste izmenili lekove sa id-em: ";
            for (String x: uspesno) {
                result += x + ", ";
            }
        }

        if(neuspesno.size() > 0) {
            result += "\nNeuspesno ste izmenili lekove sa id-em: ";
            for (String x: neuspesno) {
                result += x + ", ";
            }
        }
        return result;
    }

    public List<NarudzbenicaViewModel> dajSveNarudzbine() {
        List<Narudzbenica> narudzbenice = narudzbenicaRepository.findAll();
        List<NarudzbenicaViewModel> narudzbenicaViewModels = new ArrayList<NarudzbenicaViewModel>();
        for (Narudzbenica narudzbenica: narudzbenice) {
            NarudzbenicaViewModel narudzbenicaViewModel = dajNarudzbenicuPoId(narudzbenica.getId());
            narudzbenicaViewModels.add(narudzbenicaViewModel);
        }
        return narudzbenicaViewModels;
    }
}
