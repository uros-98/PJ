package com.asss.pj.dao;

import com.asss.pj.entity.Lek;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Date;
import java.util.List;

@Repository
public interface LekRepository extends JpaRepository<Lek, Integer> {

    @Query("from Lek order by 'id' desc")
    List<Lek> findAll();

    @Query("select l from Lek l where l.id = ?1")
    Lek findById(int id);

    @Query("select l from Lek l where l.naziv like %?1%")
    List<Lek> pretraziLekPoNazivu(String naziv);

    @Modifying
    @Transactional
     @Query("INSERT INTO Lek (id, naziv, tip, proizvodjac, rokTrajanja, cena) VALUES (NULL, :naziv, :tip, :proizvodjac, :rokTrajanja, :cena)")
     int dodajLek(@Param("naziv")String naziv, @Param("tip")String tip, @Param("proizvodjac")String proizvodjac, @Param("cena")int cena, @Param("rokTrajanja")Date rokTrajanja);

    @Modifying
    @Transactional
    @Query("update Lek l set l.naziv = :naziv, l.tip = :tip, l.proizvodjac = :proizvodjac, l.cena = :cena, l.rokTrajanja = :rokTrajanja where l.id = :id")
    int izmeniLek(@Param("id") int id, @Param("naziv")String naziv, @Param("tip")String tip, @Param("proizvodjac")String proizvodjac, @Param("cena")int cena, @Param("rokTrajanja")Date rokTrajanja);

    @Modifying
    @Transactional
    @Query("delete from Lek l where l.id = ?1")
    int obrisiLek(int id);
}
