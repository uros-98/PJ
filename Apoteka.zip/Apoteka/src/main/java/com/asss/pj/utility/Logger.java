package com.asss.pj.utility;

import java.io.FileWriter;
import java.io.PrintWriter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class Logger {

    public static String fileName = "Logger.txt";

    public static void upisivanjeRequestULogger(String tipRequest, String url, Object request) {
        PrintWriter izlaz;
        try {
            izlaz = new PrintWriter(new FileWriter(fileName, true));
        }catch (Exception e){
            System.out.println("Ulazna datoteka nije pronađena.");
            return;
        }
        izlaz.println("---------------------------------");
        izlaz.println("Tip zahteva: " + tipRequest);
        izlaz.println("URL: " + url);

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = "";
        try {
            json = ow.writeValueAsString(request);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        izlaz.println("Request: " +json);
        izlaz.close();
    }

    public static void upisivanjeResponseULogger(Object response) {
        PrintWriter izlaz;
        try {
            izlaz = new PrintWriter(new FileWriter(fileName, true));
        }catch (Exception e){
            System.out.println("Ulazna datoteka nije pronađena.");
            return;
        }
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = "";
        try {
            json = ow.writeValueAsString(response);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        izlaz.println("Response:" + json);
        izlaz.println("---------------------------------");
        izlaz.close();
    }
}
