package com.asss.pj.ViewModels;

public class LekKolicinaBasic {
    private int lekId;
    private int kolicina;

    public LekKolicinaBasic() {
    }

    public LekKolicinaBasic(int lekId, int kolicina) {
        this.lekId = lekId;
        this.kolicina = kolicina;
    }

    public int getLekId() {
        return lekId;
    }

    public void setLekId(int lekId) {
        this.lekId = lekId;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }
}
