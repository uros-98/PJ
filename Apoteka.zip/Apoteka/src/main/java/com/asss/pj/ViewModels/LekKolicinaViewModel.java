package com.asss.pj.ViewModels;

import com.asss.pj.entity.Lek;

public class LekKolicinaViewModel {
    private Lek lek;
    private int kolicina;

    public LekKolicinaViewModel(Lek lek, int kolicina) {
        this.lek = lek;
        this.kolicina = kolicina;
    }
    public LekKolicinaViewModel() {
    }

    public Lek getLek() {
        return lek;
    }

    public void setLek(Lek lek) {
        this.lek = lek;
    }

    public int getKolicina() {
        return kolicina;
    }
    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }
}
