package com.asss.pj.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "prodaja")
public class Prodaja {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private Date datum;
    private double ukupnaCena;

    public Prodaja() {
    }

    public Prodaja(int id, Date datum, double ukupnaCena) {
        this.id = id;
        this.datum = datum;
        this.ukupnaCena = ukupnaCena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public double getUkupnaCena() {
        return ukupnaCena;
    }

    public void setUkupnaCena(int ukupnaCena) {
        this.ukupnaCena = ukupnaCena;
    }
}
