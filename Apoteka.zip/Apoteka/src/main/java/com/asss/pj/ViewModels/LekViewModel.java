package com.asss.pj.ViewModels;

import java.util.Date;

public class LekViewModel {
    private String naziv;
    private String tip;
    private String proizvodjac;
    private Date datum;
    private int cena;

    public LekViewModel() {
    }

    public LekViewModel(String naziv, String tip, String proizvodjac, Date datum, int cena) {
        this.naziv = naziv;
        this.tip = tip;
        this.proizvodjac = proizvodjac;
        this.datum = datum;
        this.cena = cena;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getProizvodjac() {
        return proizvodjac;
    }

    public void setProizvodjac(String proizvodjac) {
        this.proizvodjac = proizvodjac;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }
}
