package com.asss.pj.service;

import com.asss.pj.ViewModels.NarudzbenicaViewModel;
import com.asss.pj.ViewModels.NarudzbinaKreiranje;
import com.asss.pj.ViewModels.StatusUpdate;
import com.asss.pj.entity.Narudzbenica;
import java.util.List;

public interface NarudzbenicaService {

    List<Narudzbenica> findAll();

    NarudzbenicaViewModel dajNarudzbenicuPoId(int id);
    List<NarudzbenicaViewModel> dajSveNarudzbine();

    String updateStatus(StatusUpdate statusUpdate);

    String kreiranje(NarudzbinaKreiranje novaNarudzbina);

    String izmeni(NarudzbinaKreiranje narudzbina);
}
