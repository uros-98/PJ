package com.asss.pj.service;

import com.asss.pj.ViewModels.LekViewModel;
import com.asss.pj.dao.LekRepository;
import com.asss.pj.entity.Lek;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LekServiceImpl  implements LekService{

    @Autowired
    private LekRepository lekRepository;

    @Override
    public List<Lek> pretraziLekPoNazivu(String naziv) {
         return lekRepository.pretraziLekPoNazivu(naziv);
    }
    @Override
    public List<Lek> findAll() {
        return lekRepository.findAll();
    }
    @Override
    public Lek pretraziLekPoId(int id) {
        return lekRepository.findById(id);
    }
    @Override
    public String dodajLek(LekViewModel lek) {

        try {
            int result = lekRepository.dodajLek(lek.getNaziv(), lek.getTip(), lek.getProizvodjac(), lek.getCena(), lek.getDatum());
            if (result == 1) {
                return "Uspensno ste dodali lek";
            }
        } catch (Exception e) {
            return "Niste uspensno dodali lek";
        }
        return "Niste uspensno dodali lek";
    }

    @Override
    public String izmeniLek(int id, LekViewModel lek) {
        try {
            int result = lekRepository.izmeniLek(id, lek.getNaziv(), lek.getTip(), lek.getProizvodjac(), lek.getCena(), lek.getDatum());
            if (result == 1) {
                return "Uspensno ste izmenili lek sa id: " + id;
            }
        } catch (Exception e) {
            return "Niste uspensno izmenili lek sa id: " + id;
        }
         return "Niste uspensno izmenili lek sa id: " + id;
    }

    @Override
    public String obrisiLek(int id)  {
        Lek lek = lekRepository.findById(id);
        if(lek == null) {
            return "Ne postoji lek sa id-em: " + id;
        }
        try {
            int result = lekRepository.obrisiLek(id);
            if (result == 1) {
                return "Uspensno ste obrisali lek sa id: " + id;
            }
        } catch (Exception e) {
            return "Niste uspensno obrisali lek sa id: " + id;
        }
        return "Niste uspensno obrisali lek sa id: " + id;
    }
}
