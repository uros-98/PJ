package com.asss.pj.service;

import com.asss.pj.ViewModels.ProdajaViewModel;
import com.asss.pj.entity.LekProdaja;
import java.util.List;

public interface ProdajaService {

    ProdajaViewModel dajProdajuPoId(int id);
    List<LekProdaja> getLekProdaja(int id);
    List<ProdajaViewModel> dajSveProdaje();
}
