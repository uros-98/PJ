package com.asss.pj.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "narudzbenica")
public class Narudzbenica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private Date datum;
    private String statusIsporuke;

    public Narudzbenica() {
    }

    public Narudzbenica(int id, Date datum, String statusIsporuke) {
        this.id = id;
        this.datum = datum;
        this.statusIsporuke = statusIsporuke;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getStatusIsporuke() {
        return statusIsporuke;
    }

    public void setStatusIsporuke(String statusIsporuke) {
        this.statusIsporuke = statusIsporuke;
    }
}
