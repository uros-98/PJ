package com.asss.pj.controller;

import com.asss.pj.ViewModels.NarudzbenicaViewModel;
import com.asss.pj.ViewModels.NarudzbinaKreiranje;
import com.asss.pj.ViewModels.StatusUpdate;
import com.asss.pj.service.NarudzbenicaService;
import com.asss.pj.utility.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/narudzbenica")
public class NarudzbenicaRestController {

    @Autowired
    private NarudzbenicaService narudzbenicaService;

    @GetMapping("/{id}")
    public NarudzbenicaViewModel dajNarudzbenicuPoId(@PathVariable int id) {
        Logger.upisivanjeRequestULogger("Get", "/narudzbenica/" + id, "");
        NarudzbenicaViewModel response = narudzbenicaService.dajNarudzbenicuPoId(id);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @GetMapping("/dajSveNarudzbine")
    public List<NarudzbenicaViewModel> dajSveNarudzbine() {
        Logger.upisivanjeRequestULogger("Get", "/narudzbenica/dajSveNarudzbine", "");
        List<NarudzbenicaViewModel> response = narudzbenicaService.dajSveNarudzbine();
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @PostMapping("/updatestatus")
    public String updateStatus(@RequestBody StatusUpdate statusUpdate) {
        Logger.upisivanjeRequestULogger("Post", "/narudzbenica/updatestatus", statusUpdate);
        String response = narudzbenicaService.updateStatus(statusUpdate);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @PostMapping("/dodaj")
    public String dodaj(@RequestBody NarudzbinaKreiranje novaNarudzbina) {
        Logger.upisivanjeRequestULogger("Post", "/narudzbenica/dodaj", novaNarudzbina);
        String response = narudzbenicaService.kreiranje(novaNarudzbina);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }

    @PostMapping("/izmeni")
    public String izmeni(@RequestBody NarudzbinaKreiranje narudzbina) {
        Logger.upisivanjeRequestULogger("Post", "/narudzbenica/izmeni", narudzbina);
        String response = narudzbenicaService.izmeni(narudzbina);
        Logger.upisivanjeResponseULogger(response);
        return response;
    }
}
