package com.asss.pj.service;

import com.asss.pj.ViewModels.LekViewModel;
import com.asss.pj.entity.Lek;
import java.util.List;

public interface LekService {

    List<Lek> pretraziLekPoNazivu(String naziv);

    List<Lek> findAll();

    Object dodajLek(LekViewModel lek);

    String izmeniLek(int id, LekViewModel lek);

    String obrisiLek(int id);

    Lek pretraziLekPoId(int id);
}
