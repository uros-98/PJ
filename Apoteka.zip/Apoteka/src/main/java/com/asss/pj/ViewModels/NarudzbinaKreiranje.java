package com.asss.pj.ViewModels;

import java.util.Date;
import java.util.List;
public class NarudzbinaKreiranje {

    private int idNarudzbenice;
    private Date datum;
    private String status;
    private List<LekKolicinaBasic> lekKolicina;

    public NarudzbinaKreiranje() {
    }

    public NarudzbinaKreiranje(Date datum, String status, List<LekKolicinaBasic> lekKolicina) {
        this.datum = datum;
        this.status = status;
        this.lekKolicina = lekKolicina;
    }

    public NarudzbinaKreiranje(int idNarudzbenice, Date datum, String status, List<LekKolicinaBasic> lekKolicina) {
        this.datum = datum;
        this.status = status;
        this.lekKolicina = lekKolicina;
        this.idNarudzbenice = idNarudzbenice;
    }
    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<LekKolicinaBasic> getLekKolicina() {
        return lekKolicina;
    }

    public void setLekKolicina(List<LekKolicinaBasic> lekKolicina) {
        this.lekKolicina = lekKolicina;
    }

    public int getIdNarudzbenice() {
        return idNarudzbenice;
    }

    public void setIdNarudzbenice(int idNarudzbenice) {
        this.idNarudzbenice = idNarudzbenice;
    }
}
