package com.asss.pj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApotekaApplication {

	public static void main(String[] args) {

		SpringApplication.run(ApotekaApplication.class, args);
	}

}
