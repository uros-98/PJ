package com.asss.pj.dao;

import com.asss.pj.entity.LekProdaja;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface LekProdajaRepository extends JpaRepository<LekProdaja, Integer> {

    @Query("select lp from LekProdaja lp where lp.idProdaje = ?1")
    List<LekProdaja> getLekByProdajaId(int idProdaje);
}
