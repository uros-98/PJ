package com.asss.pj.ViewModels;

import java.util.Date;
import java.util.List;

public class ProdajaViewModel {
    private Date datum;
    private double ukupnaCena;
    private List<LekKolicinaViewModel> lekovi;

    public ProdajaViewModel(Date datum, double ukupnaCena, List<LekKolicinaViewModel> lekovi) {
        this.datum = datum;
        this.ukupnaCena = ukupnaCena;
        this.lekovi = lekovi;
    }

    public ProdajaViewModel() {
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public double getUkupnaCena() {
        return ukupnaCena;
    }

    public void setUkupnaCena(double ukupnaCena) {
        this.ukupnaCena = ukupnaCena;
    }

    public List<LekKolicinaViewModel> getLekovi() {
        return lekovi;
    }

    public void setLekovi(List<LekKolicinaViewModel> lekovi) {
        this.lekovi = lekovi;
    }
}
