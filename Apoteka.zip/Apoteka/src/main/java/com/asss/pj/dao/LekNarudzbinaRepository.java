package com.asss.pj.dao;

import com.asss.pj.entity.LekNarudzbina;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface LekNarudzbinaRepository extends JpaRepository<LekNarudzbina, Integer> {

    @Query("select lna from LekNarudzbina lna where lna.idNarudzbine = ?1")
    List<LekNarudzbina> dajLekNarudzbinePoNarudzbinaId(int narudzbinaId);

    @Modifying
    @Transactional
    @Query("insert into LekNarudzbina (idLeka, idNarudzbine, kolicina) values (:lekId, :narudzbinaId, :kolicina)")
    int dodaj(@Param("narudzbinaId") int narudzbinaId,@Param("lekId") int lekId,@Param("kolicina") int kolicina);

    @Modifying
    @Transactional
    @Query("delete from LekNarudzbina lna where lna.idNarudzbine = ?1")
    int obrisiPoNarudzbinaId(int idNarudzbine);
}
