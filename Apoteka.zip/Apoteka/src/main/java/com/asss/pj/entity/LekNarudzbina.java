package com.asss.pj.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "leknarudzbina")
public class LekNarudzbina {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int idLeka, idNarudzbine;
    private int kolicina;

    public LekNarudzbina() {
    }

    public LekNarudzbina(int id, int idLeka, int idNarudzbine, int kolicina) {
        this.id = id;
        this.idLeka = idLeka;
        this.idNarudzbine = idNarudzbine;
        this.kolicina = kolicina;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdLeka() {
        return idLeka;
    }

    public void setIdLeka(int idLeka) {
        this.idLeka = idLeka;
    }

    public int getIdNarudzbine() {
        return idNarudzbine;
    }

    public void setIdNarudzbine(int idNarudzbine) {
        this.idNarudzbine = idNarudzbine;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }
}
