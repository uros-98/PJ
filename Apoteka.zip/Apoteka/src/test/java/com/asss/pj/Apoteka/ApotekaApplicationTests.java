package com.asss.pj.Apoteka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApotekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
